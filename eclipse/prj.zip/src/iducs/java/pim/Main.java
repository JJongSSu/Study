package iducs.java.pim;

import iducs.java.pim.controller.MemberController;

public class Main {

    public static void main(String[] args) {
        new MemberController().dispatch();
    }
}
